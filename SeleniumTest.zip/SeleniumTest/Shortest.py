import time

from selenium import webdriver
from selenium.webdriver import Keys
from selenium.webdriver.common.by import By

driver = webdriver.Chrome()

driver.maximize_window()

driver.get("https://www.google.com/")

driver.find_element(By.NAME, "q").send_keys("Dhaka")

time.sleep(3)

# driver.find_element(By.NAME, "btnK").send_keys(Keys.ENTER)

driver.find_element(By.CLASS_NAME, "wM6W7d").click()


time.sleep(40)




# driver.close()

print("sample test case successfully completed")
