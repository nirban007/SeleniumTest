from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from datetime import datetime
import openpyxl
from selenium.webdriver.common.by import By
import os

# open existing Excel sheet
workbook = openpyxl.load_workbook('Excel/Excel.xlsx')
sheet = workbook.active

# read keyword from Excel sheet
keyword = sheet.cell(1, 1).value

# create webdriver instance
driver = webdriver.Chrome()

# navigate to Google Search page
driver.get("https://www.google.com")

# find search box element and enter search query
search_box = driver.find_element(By.NAME, "q")
search_box.send_keys(keyword)

search_box.send_keys(Keys.RETURN)

# extract all suggested web pages
suggestions = driver.find_elements(By.CLASS_NAME, "wM6W7d")
suggestions_text = [sugg.text for sugg in suggestions]

#find the longest and shortest suggestion
longest_suggestion = max(suggestions_text, key=len)
shortest_suggestion = min(suggestions_text, key=len)

# get current date and time
now = datetime.now()
date_time = now.strftime("%Y-%m-%d %H:%M:%S")

# get current number of rows
current_row = sheet.max_row

# write date, first and last suggestions to Excel sheet
sheet.cell(current_row+6,4).value = date_time
sheet.cell(current_row+4,4).value = keyword
sheet.cell(current_row+4,4).value = longest_suggestion
sheet.cell(current_row+5,4).value = shortest_suggestion
workbook.save('Excel/Excel.xlsx')

# close webdriver
driver.close()


print("Process Done")
