from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from datetime import datetime
import openpyxl
from selenium.webdriver.common.by import By
import os

# open existing Excel sheet
workbook = openpyxl.load_workbook('Excel/Excel.xlsx')
sheet = workbook.active

# get the number of rows in the sheet
row_count = sheet.max_row

# create webdriver instance
driver = webdriver.Chrome()

# loop through the rows of the Excel sheet
for i in range(1, row_count + 1):
    # read keyword from Excel sheet
    keyword = sheet.cell(i, 3).value

    # navigate to Google Search page
    driver.get("https://www.google.com")

    # find search box element and enter search query
    search_box = driver.find_element(By.NAME, "q")
    search_box.send_keys(keyword)

    search_box.send_keys(Keys.RETURN)

    # extract all suggested web pages
    suggestions = driver.find_elements(By.CLASS_NAME, "wM6W7d")
    suggestions_text = [sugg.text for sugg in suggestions]

    # find the longest and shortest suggestion
    longest_suggestion = max(suggestions_text, key=len)
    shortest_suggestion = min(suggestions_text, key=len)

    # get current date and time
    now = datetime.now()
    date_time = now.strftime("%Y-%m-%d %H:%M:%S")

    # write date and time to specific cell in the Excel sheet
    sheet.cell(i, 3).value = date_time
    sheet.cell(i, 2).value = keyword
    sheet.cell(i, 4).value = longest_suggestion
    sheet.cell(i, 5).value = shortest_suggestion

workbook.save('Excel/Excel.xlsx')

# close webdriver
driver.close()
