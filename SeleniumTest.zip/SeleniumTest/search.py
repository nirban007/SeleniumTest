from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from datetime import datetime, time
import openpyxl
import os
from selenium.webdriver.common.by import By


# open the Excel sheet
workbook = openpyxl.load_workbook('Excel/Excel.xlsx')
sheet = workbook.active

# get the column that contains the keywords
keywords = sheet['C'] # assuming keywords are in column A

# create webdriver instance
# create webdriver instance
driver = webdriver.Chrome()

# navigate to Google Search page
driver.get("https://www.google.com")

# find search box element and enter search query
search_box = driver.find_element(By.NAME, "q")
search_box.send_keys("Saturday")
search_box.send_keys(Keys.RETURN)

# get all suggested web pages
suggestions = driver.find_elements(By.CLASS_NAME, "wM6W7d")

# get the text of each suggestion
suggestions_text = [suggestion.text for suggestion in suggestions]

# get current date and time
now = datetime.now()
date_time = now.strftime("%Y-%m-%d %H:%M:%S")



# get the longest and shortest suggestion
longest_suggestion = max(suggestions_text, key=len)


shortest_suggestion = min(suggestions_text, key=len)

# open existing Excel sheet
workbook = openpyxl.load_workbook('Excel/Excel.xlsx')
sheet = workbook.active

# get current number of rows
current_row = sheet.max_row

# write date, first and last suggestions to Excel sheet
sheet.cell(3,6).value = date_time
sheet.cell(3,5).value = longest_suggestion
sheet.cell(3,4).value = shortest_suggestion

os.chmod('Excel/Excel.xlsx', 0o777)

workbook.save('Excel/Excel.xlsx')

# close webdriver
driver.close()

